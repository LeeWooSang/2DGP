import random
import json
import os

from pico2d import *
import game_framework
import title_state

name = "MainState"

laborer = None
stage = None
font = None

class Stage:
    def __init__(self):
        self.image = load_image('office.png')

    def draw(self):
        self.image.draw(400, 300)

class Laborer1:
    def __init__(self):
        self.x, self.y = 30, 90
        self.frame = 0
        self.image = load_image('Boy_animation.png')
        self.dir = 1

    def update(self):
        self.frame = (self.frame + 1) % 4
        delay(0.03)
        self.x += self.dir
        if self.x >= 230:
            self.dir = -1
        elif self.x <= 30:
            self.dir = 1

    def draw(self):
        self.image.clip_draw(self.frame * 90, 0, 72, 150, self.x, self.y)

class Laborer2:
    def __init__(self):
        self.x, self.y = 400, 250
        self.frame = 0
        self.image = load_image('Boy_animation.png')
        self.dir = 1

    def update(self):
        self.frame = (self.frame + 1) % 4
        delay(0.03)
        self.x += self.dir
        if self.x >= 600:
            self.dir = -1
        elif self.x <= 400:
            self.dir = 1

    def draw(self):
        self.image.clip_draw(self.frame * 90, 0, 72, 150, self.x, self.y)

def enter():
    global laborer1, laborer2, stage

    laborer1 = Laborer1()
    laborer2 = Laborer2()
    stage = Stage()


def exit():
    global laborer1, stage
    del (laborer1)
    del (laborer2)
    del (stage)


def pause():
    pass


def resume():
    pass


def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key ==  SDLK_ESCAPE:
            game_framework.change_state(title_state)

def update():
    laborer1.update()
    laborer2.update()


def draw():
    clear_canvas()
    stage.draw()
    laborer1.draw()
    laborer2.draw()
    update_canvas()

