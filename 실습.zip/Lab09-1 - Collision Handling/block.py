import random

from pico2d import *

class Block:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    Block_SPEED_KMPH = 20.0  # Km / Hour
    Block_SPEED_MPM = (Block_SPEED_KMPH * 1000.0 / 60.0)
    Block_SPEED_MPS = (Block_SPEED_MPM / 60.0)
    Block_SPEED_PPS = (Block_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 1

    image = None
    LEFT, RIGHT = -1, 1

    def __init__(self):
        self.x, self.y = 0, 200
        self.state = self.RIGHT
        self.move_speed = 100
        self.dir = 1

        if Block.image == None:
            Block.image = load_image('brick180x40.png')

    def draw(self):
        self.image.draw(self.x, self.y)

    def update(self, frame_time):
        distance = Block.Block_SPEED_PPS * frame_time
        self.x += self.dir * distance

        if self.x > 800 :
            self.state = self.LEFT
            self.x = 800
            self.dir = -1

        elif self.x < 0:
            self.state = self.RIGHT
            self.x = 0
            self.dir = 1

    def get_bb(self):
        return self.x -90, self.y - 20, self.x + 90, self.y + 20

    def draw_bb(self):
        return draw_rectangle(*self.get_bb())

