import game_framework
import collision

game_framework.run(collision)
