import random

from pico2d import *

class Laborer:
    PIXEL_PER_METER = (10.0 / 0.3)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 20.0                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 4

    image = None

    LEFT_RUN, RIGHT_RUN = 0, 1

    def __init__(self):
        self.x, self.y = 100, 90
        self.frame = random.randint(0, 7)
        self.life_time = 0.0
        self.total_frames = 0.0
        self.dir = 0
        self.state = self.RIGHT_RUN

        if Laborer.image == None:
            Laborer.image = load_image('Boy_animation2_sheet.png')


    def update(self, frame_time):
        def clamp(minimum, x, maximum):
            return max(minimum, min(x, maximum))

        self.life_time += frame_time
        distance = Laborer.RUN_SPEED_PPS * frame_time
        self.total_frames += Laborer.FRAMES_PER_ACTION * Laborer.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % 4
        self.x += (self.dir * distance)

        self.x = clamp(0, self.x, 800)

    def draw(self):
        self.image.clip_draw(self.frame * 90, self.state * 150, 90, 140, self.x, self.y)

    def get_bb(self):
        return self.x - 15, self.y - 40, self.x + 15, self.y + 40

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def handle_left_run(self, frame_time):
        self.x -= 5

        if self.x < 100:
            self.x = 100
            self.state = self.RIGHT_RUN


    def handle_right_run(self, frame_time):
            self.x += 5

            if self.x > 220:
                self.x = 220
                self.state = self.LEFT_RUN


    handle_state = {
        LEFT_RUN: handle_left_run,
        RIGHT_RUN: handle_right_run
    }





