import random

from pico2d import *

class Menu:
    def __init__(self):
        self.image = load_image('menu1.png')

    def draw(self):
        self.image.draw(250, 550)

