import random

from pico2d import *

class Coin:
    image = None

    def __init__(self):
        self.x, self.y = 70, 50
        if Coin.image == None:
            Coin.image = load_image('coin.png')

    def draw(self):
        self.image.draw(self.x, self.y)

    def update(self, frame_time):
        pass

    def get_bb(self):
        return self.x -20, self.y - 20, self.x + 20, self.y + 20